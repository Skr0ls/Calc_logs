﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CALC_FILES_PR_N9
{
    public partial class Form1 : Form
    {
        static string str = DateTime.Now.ToString("dd.MM.yy HH.mm.ss");
        FileStream log = new FileStream($"Logs\\log_{str}.txt", FileMode.Create, FileAccess.Write);
        FileStream res = new FileStream($"Result\\result_{str}.txt", FileMode.Create, FileAccess.Write);
        int counter = 0;

        bool textchanged = false;

        public Form1()
        {
            InitializeComponent();

        }

        private void Btn_res_Click(object sender, EventArgs e)
        {
            string str2 = DateTime.Now.ToString("HH.mm.ss");
            byte[] buffer = Encoding.Default.GetBytes($"[{str2}] Нажата кнопка: {counter++};\n");
            log.WriteAsync(buffer, 0, buffer.Length);
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "") throw new Exception("Поля пусты");

                textBox3.Text = textBox1.Text.Trim() + textBox2.Text;
                byte[] wordplus = Encoding.Default.GetBytes($"[{str2}] {textBox3.Text};\n");
                res.WriteAsync(wordplus, 0, wordplus.Length);
            }
            catch (Exception m)
            {
                textBox3.Text = "";
                MessageBox.Show(m.Message,"Ошибка",MessageBoxButtons.OK,MessageBoxIcon.Error);
                byte[] error = Encoding.Default.GetBytes($"[{str2}] Вызвана ошибка: [{m.Message}];\n");
                log.WriteAsync(error, 0, error.Length);
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string str2 = DateTime.Now.ToString("HH.mm.ss");
            byte[] clsd = Encoding.Default.GetBytes($"[{str2}] Приложение завершило работу.");
            log.WriteAsync(clsd, 0, clsd.Length);
            log.Close();
            res.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textchanged = true;
            string str2 = DateTime.Now.ToString("HH.mm.ss");
            if (textchanged == true)
            {
                byte[] text1 = Encoding.Default.GetBytes($"[{str2}] Изменение содержимого текстовых полей;\n");
                log.WriteAsync(text1, 0, text1.Length);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textchanged = true;
            string str2 = DateTime.Now.ToString("HH.mm.ss");
            if (textchanged == true)
            {
                byte[] text2 = Encoding.Default.GetBytes($"[{str2}] Изменение содержимого текстовых полей;\n");
                log.WriteAsync(text2, 0, text2.Length);
            }
        }
    }
}
